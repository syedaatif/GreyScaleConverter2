onmessage = function(e) {postMessage(filter(e.data))};
function filter(imgd) {
var pix = imgd.image4Data.data;

for (var i = 0, n = pix.length; i < n; i += 4) {
var grayscale = pix[i] * .3 + pix[i+1] * .59
+ pix[i+2] * .11;
pix[i] = grayscale; // red
pix[i+1] = grayscale; // green
pix[i+2] = grayscale; // blue
}
imgd['image4Data'].data = pix;
return imgd;

}




