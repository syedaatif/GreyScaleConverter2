
//Split the images data array that was retreived and store it in session storage.
function imageStorage(imgUrlData)
{
  arraySplit = imgUrlData.split(" ");
  sessionStorage.setItem("img1", arraySplit[0]);
  sessionStorage.setItem("img2", arraySplit[1]);
  sessionStorage.setItem("img3", arraySplit[2]);

  loadCanvas();
}


//Load the canvas and retrieve the data from session storage
function loadCanvas()
{
var canvas = document.getElementById('myCanvas');
var context = canvas.getContext('2d');
// load images from data url
var imageObj1 = new Image();
imageObj1.onload = function ()
{
context.drawImage(this, 0, 0);
};
imageObj1.src = sessionStorage.getItem("img1");

var imageObj2 = new Image();
imageObj2.onload = function () {
context.drawImage(this, 200, 100);
};
imageObj2.src = sessionStorage.getItem("img2");

var imageObj3 = new Image();
imageObj3.onload = function ()
{
    context.drawImage(this, 300, 100);
};
imageObj3.src = sessionStorage.getItem("img3");
}


//Function to retreive image data from textfile using ajax request.(all 3 images in single http)
window.onload = function ()
{
  var request = new XMLHttpRequest();
  request.open("GET", "data.txt", true);
  request.onreadystatechange = function ()
  {
      if (request.readyState == 4)
      {//checks if the request is fulfilled or not
          if (request.status == 200)
          {//200 -300 is success..301 to 400 is error
              imageStorage(request.responseText);
          }
      }
  };
  request.send(null);
}

function greyimg(array1)
{
    var canvas = document.getElementById('myCanvas');
    var context = canvas.getContext('2d');
    var image4Data = context.getImageData(0, 0, canvas.width, canvas.height);
        // load image from data url
    var imageObj4 = new Image();
    imageObj4.onload = function()
      { context.drawImage(this, 500, 100);
       };
     //  imageObj4.src =array1[0];
//var pixels = image4Data;
var worker = new Worker("myworkerimage.js");
var obj =
  {
    image4Data:image4Data
  }

//}
post=function()
  {
worker.postMessage(obj);
console.log('message posted to worker');
  }
post(obj);
worker.onmessage = function(e)
 {
  new_pixels = e.data.image4Data;

console.log('message received from worker')
var canvas=document.getElementById('myCanvas');
var context=canvas.getContext('2d');
 context.putImageData(new_pixels, 0, 0);
image5 = new Image();
imagData = context.getImageData(0, 0, canvas.width, canvas.height);
 image5.onload = function()
    {
      context.drawImage(this, 100, 100);
    };
image5.src =imagData.toDataURL();
 }
}
